public class queue{

    int queue[]=new int[5];
    int size, front, rear;
     public void enQueue(int data) {
        queue[rear]=data;
        rear=(rear+1)%5;
        size=size+1;
    }

    public int deQueue(){
         int data=queue[front];
         front=(front+1)%5;
         size=size+1;

         return data;


    }

    public void show()
    {
        System.out.println("Elements : ");
        for(int i=0;i<size;i++){

            System.out.println(queue[(front+i)%5]+" ");

        }
    }
    public int getSize(){

        return size;
    }

    public boolean isEmpty(){
        return size==0;
    }
    public boolean isFull(){
        return size==5;
    }
    public static void main(String[] args) {
        queue q= new queue();
        q.enQueue(5);
        q.enQueue(2);
        q.enQueue(3);
       q.enQueue(4);
      // q.enQueue(8);

      // q.deQueue();
       // q.deQueue();

        System.out.println(q.isEmpty());
    
System.out.println("Size "+q.getSize());
        q.show();
    }
}