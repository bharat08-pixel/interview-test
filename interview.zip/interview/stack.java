public class stack {

    int stack[]=new int[5];
    int top=0;
    int size;
    public void push(int data){
        stack[top]=data;
        top++;


    }

    public int pop(){
        int data;
        top--;
        data=stack[top];
        stack[top]=0;
        
        return data;
    }
    public void show()
    {
        for(int n:stack)
        {
            System.out.print(n+"");
        }
    }
   

    
    public static void main(String[] args) {
       

        stack nums=new stack();
        nums.push(15);
       nums.push(8);
        nums.push(10);

        System.out.println( nums.pop());
       


        nums.show();
    }
}
